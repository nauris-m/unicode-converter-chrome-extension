/*
const text = document.getElementById( 'notify-text' );
const notify = document.getElementById( 'notify-button' );
const reset = document.getElementById( 'notify-reset' );
const counter = document.getElementById( 'notify-count' );

chrome.storage.local.get( ['notifyCount'], data => {
	let value = data.notifyCount || 0;
	counter.innerHTML = value;
} );

chrome.storage.onChanged.addListener( ( changes, namespace ) => {
	if ( changes.notifyCount ) {
		let value = changes.notifyCount.newValue || 0;
		counter.innerHTML = value;
	}
});

reset.addEventListener( 'click', () => {
	chrome.storage.local.clear();
	text.value = '';
} );

notify.addEventListener( 'click', () => {
	chrome.runtime.sendMessage( '', {
		type: 'notification',
		message: text.value
	});
} );
*/


        function escapeUnicode(str) {
            return str.replace(/[^\u0000-\u007F]/g, function(char) {
                return '\\u' + ('0000' + char.charCodeAt(0).toString(16)).slice(-4);
            });
        }

        function unescapeUnicode(str) {
            return str.replace(/\\u([0-9A-Fa-f]{4})/g, function(match, grp) {
                return String.fromCharCode(parseInt(grp, 16));
            });
        }

        function escapeText() {
            const input = document.getElementById('inputText').value;
            const result = escapeUnicode(input);
            document.getElementById('result').textContent = result;
        }

        function unescapeText() {
            const input = document.getElementById('inputText').value;
            const result = unescapeUnicode(input);
            document.getElementById('result').textContent = result;
        }

        // Dark mode toggle
        /*const darkModeToggle = document.getElementById('darkModeToggle');
        const root = document.documentElement;
        
        darkModeToggle.addEventListener('click', () => {
            if (root.style.getPropertyValue('--bg-gradient') === 'linear-gradient(135deg, #1f1f1f 0%, #2c2c2c 100%)') {
                root.style.setProperty('--bg-gradient', 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)');
                root.style.setProperty('--text-color', '#ffffff');
                root.style.setProperty('--input-bg', 'rgba(255, 255, 255, 0.1)');
                root.style.setProperty('--button-bg', 'rgba(255, 255, 255, 0.2)');
                root.style.setProperty('--result-bg', 'rgba(0, 0, 0, 0.2)');
            } else {
                root.style.setProperty('--bg-gradient', 'linear-gradient(135deg, #1f1f1f 0%, #2c2c2c 100%)');
                root.style.setProperty('--text-color', '#e0e0e0');
                root.style.setProperty('--input-bg', 'rgba(255, 255, 255, 0.05)');
                root.style.setProperty('--button-bg', 'rgba(255, 255, 255, 0.1)');
                root.style.setProperty('--result-bg', 'rgba(255, 255, 255, 0.05)');
            }
        });*/
    
const element1 = document.getElementById('doEscape');
element1.addEventListener('click', function() {
	escapeText();
});

const element2 = document.getElementById('doUnescape');
element2.addEventListener('click', function() {
	unescapeText();
});